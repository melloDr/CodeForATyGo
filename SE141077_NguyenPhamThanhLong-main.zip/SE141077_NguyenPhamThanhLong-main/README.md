## Welcome to Math-Util repository. This repo offers various math methods used in your project as the helper ones.

### _You will find in this repo the following stuff:_
* The README.md file itself to demonstrate the MARK DOWN syntax
* .gitignore file itself to notify Git Tool how to upload source code
* MathUtility class to offer various Math functions

#### Have fun with my code and feel free to give me any comments

#### Connect me via: 
[Facebook](https://www.facebook.com/thanhlong.mello/)  
[Email](mailto: thanhlong020920@gmail.com)

#### © 2021 tramlun

# Assignment2_NguyenPhamThanhLong
