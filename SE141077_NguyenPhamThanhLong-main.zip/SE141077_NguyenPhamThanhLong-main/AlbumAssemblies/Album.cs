﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlbumAssemblies
{
    public class Album
    {
        public int AlbumID { get; set; }
        public string AlbumName { get; set; }
        public int ReleaseYear { get; set; }
        public int Quantity { get; set; }
        public int Status { get; set; }
    }
}
